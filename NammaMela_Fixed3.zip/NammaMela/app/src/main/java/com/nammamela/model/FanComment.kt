package com.nammamela.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fan_comments")
data class FanComment(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val fanName: String,
    val comment: String,
    val claps: Int = 0,
    val postedAt: Long = System.currentTimeMillis()
)
