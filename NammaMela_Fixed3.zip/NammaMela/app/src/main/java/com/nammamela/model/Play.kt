package com.nammamela.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "plays")
data class Play(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String = "Chandramukhi Rahasya",
    val language: String = "Kannada",
    val genre: String = "Drama",
    val showTime: String = "7:30 PM",
    val duration: String = "3 Hours 15 Min",
    val numberOfActs: Int = 4,
    val venue: String = "Gram Panchayat Maidan, Belagavi",
    val posterUrl: String = "https://picsum.photos/seed/drama/400/600",
    val isTonight: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
)
