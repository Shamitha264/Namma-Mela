package com.nammamela.data.db

import androidx.room.TypeConverter
import com.nammamela.model.SeatStatus

class Converters {
    @TypeConverter
    fun fromSeatStatus(status: SeatStatus): String = status.name

    @TypeConverter
    fun toSeatStatus(value: String): SeatStatus = SeatStatus.valueOf(value)
}
