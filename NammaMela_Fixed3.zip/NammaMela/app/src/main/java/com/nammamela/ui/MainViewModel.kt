package com.nammamela.ui

import androidx.lifecycle.*
import com.nammamela.data.repository.NammaMelaRepository
import com.nammamela.model.*
import kotlinx.coroutines.launch

class MainViewModel(private val repository: NammaMelaRepository) : ViewModel() {

    // Tonight's play
    val tonightPlay: LiveData<Play?> = repository.tonightPlay

    fun updatePlay(play: Play) {
        viewModelScope.launch {
            repository.updatePlay(play)
        }
    }

    // Seats
    val allSeats: LiveData<List<Seat>> = repository.allSeats
    val availableCount: LiveData<Int> = repository.availableCount
    val bookedCount: LiveData<Int> = repository.bookedCount
    val totalCount: LiveData<Int> = repository.totalCount

    private val _selectedSeats = MutableLiveData<MutableSet<String>>(mutableSetOf())
    val selectedSeats: LiveData<MutableSet<String>> = _selectedSeats

    fun toggleSeatSelection(seatId: String) {
        val current = _selectedSeats.value ?: mutableSetOf()
        if (current.contains(seatId)) current.remove(seatId)
        else current.add(seatId)
        _selectedSeats.value = current
    }

    fun clearSelection() {
        _selectedSeats.value = mutableSetOf()
    }

    fun confirmBooking(bookerName: String, onDone: (List<String>) -> Unit) {
        val seats = _selectedSeats.value?.toList() ?: return
        viewModelScope.launch {
            repository.bookMultipleSeats(seats, bookerName)
            clearSelection()
            onDone(seats)
        }
    }

    // Cast
    val mainCast: LiveData<List<CastMember>> = repository.mainCast
    val supportCast: LiveData<List<CastMember>> = repository.supportCast

    // Fan Comments
    val allComments: LiveData<List<FanComment>> = repository.allComments

    fun addComment(fanName: String, commentText: String) {
        viewModelScope.launch {
            repository.addComment(
                FanComment(
                    fanName = fanName.ifBlank { "Anonymous Fan" },
                    comment = commentText,
                    claps = 0
                )
            )
        }
    }

    fun clapForComment(commentId: Int) {
        viewModelScope.launch {
            repository.clapForComment(commentId)
        }
    }
}

class MainViewModelFactory(private val repository: NammaMelaRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
