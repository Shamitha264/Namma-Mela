package com.nammamela.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.nammamela.model.CastMember

@Dao
interface CastDao {

    @Query("SELECT * FROM cast_members ORDER BY CASE roleType WHEN 'lead' THEN 1 WHEN 'comedian' THEN 2 WHEN 'singer' THEN 3 ELSE 4 END")
    fun getAllCast(): LiveData<List<CastMember>>

    @Query("SELECT * FROM cast_members WHERE roleType IN ('lead','comedian','singer')")
    fun getMainCast(): LiveData<List<CastMember>>

    @Query("SELECT * FROM cast_members WHERE roleType = 'support'")
    fun getSupportCast(): LiveData<List<CastMember>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCastMember(member: CastMember)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllCast(members: List<CastMember>)

    @Query("SELECT COUNT(*) FROM cast_members")
    suspend fun getCount(): Int

    @Update
    suspend fun updateCastMember(member: CastMember)
}
