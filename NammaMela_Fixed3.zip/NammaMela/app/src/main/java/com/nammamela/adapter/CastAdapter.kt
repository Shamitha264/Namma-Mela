package com.nammamela.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nammamela.R
import com.nammamela.databinding.ItemCastCardBinding
import com.nammamela.model.CastMember

class CastAdapter : ListAdapter<CastMember, CastAdapter.CastViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CastViewHolder {
        val binding = ItemCastCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CastViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CastViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class CastViewHolder(private val binding: ItemCastCardBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(member: CastMember) {
            binding.tvCastName.text = member.name
            binding.tvCastRole.text = member.role
            binding.tvCastExperience.text = member.experience

            // Set role icon based on type
            val iconRes = when (member.roleType) {
                "lead" -> "👑"
                "comedian" -> "😄"
                "singer" -> "🎤"
                else -> "🎭"
            }
            binding.tvRoleIcon.text = iconRes

            Glide.with(binding.root.context)
                .load(member.photoUrl)
                .circleCrop()
                .placeholder(R.drawable.ic_person_placeholder)
                .into(binding.ivCastPhoto)

            // Highlight border based on role
            val borderColor = when (member.roleType) {
                "lead" -> R.color.gold_light
                "comedian" -> R.color.accent_orange
                "singer" -> R.color.accent_blue
                else -> R.color.gold
            }
            binding.cardCast.strokeColor = binding.root.context.getColor(borderColor)
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<CastMember>() {
        override fun areItemsTheSame(oldItem: CastMember, newItem: CastMember) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: CastMember, newItem: CastMember) = oldItem == newItem
    }
}
