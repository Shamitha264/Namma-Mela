package com.nammamela.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nammamela.databinding.ItemSupportCastBinding
import com.nammamela.model.CastMember

class SupportCastAdapter : ListAdapter<CastMember, SupportCastAdapter.SupportViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SupportViewHolder {
        val binding = ItemSupportCastBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SupportViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SupportViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class SupportViewHolder(private val binding: ItemSupportCastBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(member: CastMember) {
            binding.tvSupportName.text = member.name
            binding.tvSupportRole.text = member.role
            binding.tvSupportActs.text = member.actsAppearing

            val iconRes = when (member.role.lowercase()) {
                "villain" -> "😈"
                "backup vocalist", "vocalist" -> "🎶"
                "percussion" -> "🥁"
                "musician" -> "🎸"
                else -> "🎭"
            }
            binding.tvSupportIcon.text = iconRes
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<CastMember>() {
        override fun areItemsTheSame(oldItem: CastMember, newItem: CastMember) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: CastMember, newItem: CastMember) = oldItem == newItem
    }
}
