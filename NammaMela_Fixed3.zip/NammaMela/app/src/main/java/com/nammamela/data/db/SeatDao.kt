package com.nammamela.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.nammamela.model.Seat
import com.nammamela.model.SeatStatus

@Dao
interface SeatDao {

    @Query("SELECT * FROM seats ORDER BY sectionType, rowLabel, seatNumber")
    fun getAllSeats(): LiveData<List<Seat>>

    @Query("SELECT * FROM seats ORDER BY sectionType, rowLabel, seatNumber")
    suspend fun getAllSeatsSync(): List<Seat>

    @Query("SELECT * FROM seats WHERE rowLabel = :row ORDER BY seatNumber")
    fun getSeatsByRow(row: String): LiveData<List<Seat>>

    @Query("SELECT COUNT(*) FROM seats WHERE status = 'AVAILABLE'")
    fun getAvailableCount(): LiveData<Int>

    @Query("SELECT COUNT(*) FROM seats WHERE status = 'BOOKED'")
    fun getBookedCount(): LiveData<Int>

    @Query("SELECT COUNT(*) FROM seats")
    fun getTotalCount(): LiveData<Int>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSeat(seat: Seat)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllSeats(seats: List<Seat>)

    @Update
    suspend fun updateSeat(seat: Seat)

    @Query("UPDATE seats SET status = :status, bookedByName = :name, bookedAt = :time WHERE seatId = :seatId")
    suspend fun updateSeatStatus(seatId: String, status: SeatStatus, name: String, time: Long)

    @Query("SELECT COUNT(*) FROM seats")
    suspend fun getSeatCount(): Int

    @Query("DELETE FROM seats")
    suspend fun deleteAll()
}
