package com.nammamela.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "seats")
data class Seat(
    @PrimaryKey
    val seatId: String,          // e.g. "VIP-1", "A-3", "B-7"
    val rowLabel: String,         // "VIP", "A", "B" etc.
    val seatNumber: Int,
    val sectionType: String,      // "vip", "front", "mid", "back"
    val status: SeatStatus = SeatStatus.AVAILABLE,
    val bookedByName: String = "",
    val bookedAt: Long = 0L
)

enum class SeatStatus {
    AVAILABLE,
    SELECTED,
    BOOKED
}
