package com.nammamela.ui.seats

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.GridLayoutManager
import com.nammamela.R
import com.nammamela.adapter.SeatAdapter
import com.nammamela.databinding.FragmentSeatsBinding
import com.nammamela.model.SeatStatus
import com.nammamela.ui.MainViewModel

class SeatsFragment : Fragment() {

    private var _binding: FragmentSeatsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var seatAdapter: SeatAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSeatsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        seatAdapter = SeatAdapter { seat ->
            if (seat.status == SeatStatus.AVAILABLE || seat.status == SeatStatus.SELECTED) {
                viewModel.toggleSeatSelection(seat.seatId)
            }
        }

        binding.rvSeats.apply {
            layoutManager = GridLayoutManager(context, 10).apply {
                spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(position: Int): Int {
                        return seatAdapter.getSpanSize(position)
                    }
                }
            }
            adapter = seatAdapter
        }

        viewModel.allSeats.observe(viewLifecycleOwner) { seats ->
            val selected = viewModel.selectedSeats.value ?: emptySet()
            val updatedSeats = seats.map { seat ->
                if (seat.status == SeatStatus.AVAILABLE && selected.contains(seat.seatId))
                    seat.copy(status = SeatStatus.SELECTED)
                else if (seat.status == SeatStatus.SELECTED && !selected.contains(seat.seatId))
                    seat.copy(status = SeatStatus.AVAILABLE)
                else seat
            }
            seatAdapter.submitSeats(updatedSeats)
        }

        viewModel.selectedSeats.observe(viewLifecycleOwner) { selected ->
            val count = selected.size
            if (count > 0) {
                binding.btnBook.text = "Reserve $count Seat${if (count > 1) "s" else ""} →"
                binding.btnBook.isEnabled = true
            } else {
                binding.btnBook.text = "Select Seats to Reserve"
                binding.btnBook.isEnabled = false
            }
        }

        viewModel.availableCount.observe(viewLifecycleOwner) { avail ->
            binding.tvAvailable.text = avail.toString()
        }
        viewModel.bookedCount.observe(viewLifecycleOwner) { booked ->
            binding.tvBooked.text = booked.toString()
        }
        viewModel.totalCount.observe(viewLifecycleOwner) { total ->
            binding.tvTotal.text = total.toString()
        }

        binding.btnBook.setOnClickListener { showBookingDialog() }
    }

    private fun showBookingDialog() {
        val selected = viewModel.selectedSeats.value ?: return
        if (selected.isEmpty()) return

        val input = EditText(requireContext()).apply {
            hint = "Your name (optional)"
            setPadding(40, 20, 40, 20)
            setTextColor(android.graphics.Color.BLACK)
            setHintTextColor(android.graphics.Color.GRAY)
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        }

        AlertDialog.Builder(requireContext(), R.style.TheatricalDialog)
            .setTitle("Confirm Reservation")
            .setMessage("Reserving ${selected.size} seat(s): ${selected.joinToString(", ")}")
            .setView(input)
            .setPositiveButton("Confirm") { _, _ ->
                val name = input.text.toString().ifBlank { "Walk-in Guest" }
                viewModel.confirmBooking(name) { bookedSeats ->
                    Toast.makeText(
                        requireContext(),
                        "✓ Seats ${bookedSeats.joinToString(", ")} reserved for $name!",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .also { builder ->
                val dialog = builder.create()
                input.setOnEditorActionListener { _, actionId, _ ->
                    if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                        val name = input.text.toString().ifBlank { "Walk-in Guest" }
                        viewModel.confirmBooking(name) { bookedSeats ->
                            Toast.makeText(
                                requireContext(),
                                "✓ Seats ${bookedSeats.joinToString(", ")} reserved for $name!",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                        dialog.dismiss()
                        true
                    } else false
                }
                dialog.show()
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
