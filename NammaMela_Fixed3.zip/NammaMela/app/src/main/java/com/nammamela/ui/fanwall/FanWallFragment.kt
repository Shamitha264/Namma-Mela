package com.nammamela.ui.fanwall

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.nammamela.adapter.FanCommentAdapter
import com.nammamela.databinding.FragmentFanWallBinding
import com.nammamela.ui.MainViewModel

class FanWallFragment : Fragment() {

    private var _binding: FragmentFanWallBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var commentAdapter: FanCommentAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFanWallBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        commentAdapter = FanCommentAdapter { comment ->
            viewModel.clapForComment(comment.id)
        }

        binding.rvComments.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = commentAdapter
        }

        viewModel.allComments.observe(viewLifecycleOwner) { comments ->
            commentAdapter.submitList(comments)
            binding.tvEmptyWall.visibility = if (comments.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.btnPostComment.setOnClickListener {
            val commentText = binding.etComment.text.toString().trim()
            val fanName = binding.etFanName.text.toString().trim()

            if (commentText.isEmpty()) {
                binding.etComment.error = "Please write your applause message!"
                return@setOnClickListener
            }

            viewModel.addComment(fanName, commentText)
            binding.etComment.text?.clear()
            binding.etFanName.text?.clear()
            binding.rvComments.smoothScrollToPosition(0)
            Toast.makeText(requireContext(), "👏 Your applause posted!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
