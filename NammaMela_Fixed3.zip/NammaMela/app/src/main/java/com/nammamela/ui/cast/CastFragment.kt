package com.nammamela.ui.cast

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.nammamela.adapter.CastAdapter
import com.nammamela.adapter.SupportCastAdapter
import com.nammamela.databinding.FragmentCastBinding
import com.nammamela.ui.MainViewModel

class CastFragment : Fragment() {

    private var _binding: FragmentCastBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    private lateinit var castAdapter: CastAdapter
    private lateinit var supportAdapter: SupportCastAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCastBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        castAdapter = CastAdapter()
        supportAdapter = SupportCastAdapter()

        binding.rvMainCast.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = castAdapter
        }

        binding.rvSupportCast.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = supportAdapter
        }

        viewModel.mainCast.observe(viewLifecycleOwner) { cast ->
            castAdapter.submitList(cast)
        }

        viewModel.supportCast.observe(viewLifecycleOwner) { support ->
            supportAdapter.submitList(support)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
