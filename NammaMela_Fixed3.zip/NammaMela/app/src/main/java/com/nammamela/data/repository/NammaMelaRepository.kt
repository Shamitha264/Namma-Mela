package com.nammamela.data.repository

import androidx.lifecycle.LiveData
import com.nammamela.data.db.*
import com.nammamela.model.*

class NammaMelaRepository(
    private val playDao: PlayDao,
    private val seatDao: SeatDao,
    private val castDao: CastDao,
    private val fanCommentDao: FanCommentDao
) {
    // Play
    val tonightPlay: LiveData<Play?> = playDao.getTonightPlay()

    suspend fun updatePlay(play: Play) {
        playDao.updatePlay(play)
    }

    suspend fun getTonightPlaySync(): Play? = playDao.getTonightPlaySync()

    // Seats
    val allSeats: LiveData<List<Seat>> = seatDao.getAllSeats()
    val availableCount: LiveData<Int> = seatDao.getAvailableCount()
    val bookedCount: LiveData<Int> = seatDao.getBookedCount()
    val totalCount: LiveData<Int> = seatDao.getTotalCount()

    suspend fun bookSeat(seatId: String, bookedByName: String) {
        seatDao.updateSeatStatus(
            seatId = seatId,
            status = SeatStatus.BOOKED,
            name = bookedByName,
            time = System.currentTimeMillis()
        )
    }

    suspend fun bookMultipleSeats(seatIds: List<String>, bookedByName: String) {
        seatIds.forEach { seatId ->
            seatDao.updateSeatStatus(
                seatId = seatId,
                status = SeatStatus.BOOKED,
                name = bookedByName,
                time = System.currentTimeMillis()
            )
        }
    }

    // Cast
    val mainCast: LiveData<List<CastMember>> = castDao.getMainCast()
    val supportCast: LiveData<List<CastMember>> = castDao.getSupportCast()
    val allCast: LiveData<List<CastMember>> = castDao.getAllCast()

    // Fan Comments
    val allComments: LiveData<List<FanComment>> = fanCommentDao.getAllComments()

    suspend fun addComment(comment: FanComment) {
        fanCommentDao.insertComment(comment)
    }

    suspend fun clapForComment(commentId: Int) {
        fanCommentDao.incrementClaps(commentId)
    }

    suspend fun deleteComment(commentId: Int) {
        fanCommentDao.deleteComment(commentId)
    }
}
