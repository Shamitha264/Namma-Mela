package com.nammamela.ui.tonight

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.nammamela.NammaMelaApp
import com.nammamela.databinding.ActivityManagerUpdateBinding
import com.nammamela.model.Play
import com.nammamela.ui.MainViewModel
import com.nammamela.ui.MainViewModelFactory

class ManagerUpdateActivity : AppCompatActivity() {

    private lateinit var binding: ActivityManagerUpdateBinding
    private lateinit var viewModel: MainViewModel
    private var currentPlay: Play? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManagerUpdateBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.apply {
            title = "Update Tonight's Play"
            setDisplayHomeAsUpEnabled(true)
        }

        val repository = (application as NammaMelaApp).repository
        viewModel = ViewModelProvider(this, MainViewModelFactory(repository))[MainViewModel::class.java]

        viewModel.tonightPlay.observe(this) { play ->
            play ?: return@observe
            currentPlay = play
            if (binding.etPlayTitle.text.isNullOrEmpty()) {
                binding.etPlayTitle.setText(play.title)
                binding.etLanguage.setText(play.language)
                binding.etGenre.setText(play.genre)
                binding.etShowTime.setText(play.showTime)
                binding.etDuration.setText(play.duration)
                binding.etNumberOfActs.setText(play.numberOfActs.toString())
                binding.etVenue.setText(play.venue)
                binding.etPosterUrl.setText(play.posterUrl)
            }
        }

        binding.btnSavePlay.setOnClickListener {
            val title = binding.etPlayTitle.text.toString().trim()
            val language = binding.etLanguage.text.toString().trim()
            val genre = binding.etGenre.text.toString().trim()
            val showTime = binding.etShowTime.text.toString().trim()
            val duration = binding.etDuration.text.toString().trim()
            val acts = binding.etNumberOfActs.text.toString().trim().toIntOrNull() ?: 1
            val venue = binding.etVenue.text.toString().trim()
            val posterUrl = binding.etPosterUrl.text.toString().trim()

            if (title.isEmpty()) {
                binding.etPlayTitle.error = "Title is required"
                return@setOnClickListener
            }

            val updatedPlay = currentPlay?.copy(
                title = title,
                language = language,
                genre = genre,
                showTime = showTime,
                duration = duration,
                numberOfActs = acts,
                venue = venue,
                posterUrl = posterUrl.ifEmpty { currentPlay?.posterUrl ?: "" },
                updatedAt = System.currentTimeMillis()
            ) ?: Play(
                title = title,
                language = language,
                genre = genre,
                showTime = showTime,
                duration = duration,
                numberOfActs = acts,
                venue = venue,
                posterUrl = posterUrl
            )

            viewModel.updatePlay(updatedPlay)
            Toast.makeText(this, "✓ Play updated successfully!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
