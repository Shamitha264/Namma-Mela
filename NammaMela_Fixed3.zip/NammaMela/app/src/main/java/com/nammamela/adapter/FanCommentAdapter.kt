package com.nammamela.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nammamela.databinding.ItemFanCommentBinding
import com.nammamela.model.FanComment
import java.text.SimpleDateFormat
import java.util.*

class FanCommentAdapter(
    private val onClapClick: (FanComment) -> Unit
) : ListAdapter<FanComment, FanCommentAdapter.CommentViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CommentViewHolder {
        val binding = ItemFanCommentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CommentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CommentViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class CommentViewHolder(private val binding: ItemFanCommentBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(comment: FanComment) {
            binding.tvFanName.text = comment.fanName
            binding.tvCommentText.text = comment.comment
            binding.tvClaps.text = "👏 ${comment.claps}"
            binding.tvPostedAt.text = formatTime(comment.postedAt)

            binding.btnClap.setOnClickListener {
                onClapClick(comment)
            }
        }

        private fun formatTime(timestamp: Long): String {
            val diff = System.currentTimeMillis() - timestamp
            return when {
                diff < 60_000 -> "Just now"
                diff < 3_600_000 -> "${diff / 60_000} min ago"
                diff < 86_400_000 -> "${diff / 3_600_000} hours ago"
                else -> SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(timestamp))
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<FanComment>() {
        override fun areItemsTheSame(oldItem: FanComment, newItem: FanComment) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: FanComment, newItem: FanComment) = oldItem == newItem
    }
}
