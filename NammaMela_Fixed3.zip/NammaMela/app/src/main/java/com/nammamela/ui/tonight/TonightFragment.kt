package com.nammamela.ui.tonight

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.bumptech.glide.Glide
import com.nammamela.R
import com.nammamela.databinding.FragmentTonightBinding
import com.nammamela.ui.MainViewModel

class TonightFragment : Fragment() {

    private var _binding: FragmentTonightBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTonightBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.tonightPlay.observe(viewLifecycleOwner) { play ->
            play ?: return@observe
            binding.tvPlayTitle.text = play.title
            binding.tvPlayLanguage.text = "${play.language} • ${play.genre}"
            binding.tvShowTime.text = play.showTime
            binding.tvDuration.text = play.duration
            binding.tvActs.text = "${play.numberOfActs} Acts"
            binding.tvVenue.text = play.venue

            Glide.with(this)
                .load(play.posterUrl)
                .placeholder(R.drawable.ic_theater_mask)
                .error(R.drawable.ic_theater_mask)
                .centerCrop()
                .into(binding.ivPoster)
        }

        binding.btnManagerUpdate.setOnClickListener {
            val intent = Intent(requireContext(), ManagerUpdateActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
