package com.nammamela.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nammamela.R
import com.nammamela.databinding.ItemSeatBinding
import com.nammamela.databinding.ItemSeatHeaderBinding
import com.nammamela.model.Seat
import com.nammamela.model.SeatStatus

class SeatAdapter(
    private val onSeatClick: (Seat) -> Unit
) : ListAdapter<SeatAdapter.SeatItem, RecyclerView.ViewHolder>(DiffCallback()) {

    sealed class SeatItem {
        data class Header(val title: String, val rowLabel: String) : SeatItem()
        data class SeatCell(val seat: Seat) : SeatItem()
    }

    companion object {
        const val TYPE_HEADER = 0
        const val TYPE_SEAT = 1
        const val GRID_SPAN = 10
    }

    // Tracks section structure for span size
    private var items: List<SeatItem> = emptyList()

    fun submitSeats(list: List<Seat>?) {
        val seatItems = buildSeatItems(list ?: emptyList())
        items = seatItems
        super.submitList(seatItems)
    }

    private fun buildSeatItems(seats: List<Seat>): List<SeatItem> {
        val result = mutableListOf<SeatItem>()
        var lastSection = ""
        var lastRow = ""
        val sectionNames = mapOf(
            "vip" to "✦ VIP Section",
            "front" to "Front Rows — Premium",
            "mid" to "Middle Rows",
            "back" to "Back Rows"
        )

        for (seat in seats) {
            if (seat.sectionType != lastSection) {
                // Full-width section header
                result.add(SeatItem.Header(sectionNames[seat.sectionType] ?: seat.sectionType, ""))
                lastSection = seat.sectionType
                lastRow = ""
            }
            if (seat.rowLabel != lastRow) {
                // Row label header (occupies full span)
                result.add(SeatItem.Header("", seat.rowLabel))
                lastRow = seat.rowLabel
            }
            result.add(SeatItem.SeatCell(seat))
        }
        return result
    }

    fun getSpanSize(position: Int): Int {
        return when (items.getOrNull(position)) {
            is SeatItem.Header -> GRID_SPAN
            else -> 1
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (items.getOrNull(position)) {
            is SeatItem.Header -> TYPE_HEADER
            else -> TYPE_SEAT
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_HEADER) {
            val binding = ItemSeatHeaderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            HeaderViewHolder(binding)
        } else {
            val binding = ItemSeatBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            SeatViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = items[position]) {
            is SeatItem.Header -> (holder as HeaderViewHolder).bind(item)
            is SeatItem.SeatCell -> (holder as SeatViewHolder).bind(item.seat)
        }
    }

    override fun getItemCount() = items.size

    inner class HeaderViewHolder(private val binding: ItemSeatHeaderBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: SeatItem.Header) {
            if (item.rowLabel.isNotEmpty()) {
                binding.tvSectionTitle.visibility = View.GONE
                binding.tvRowLabel.visibility = View.VISIBLE
                binding.tvRowLabel.text = item.rowLabel
            } else {
                binding.tvSectionTitle.visibility = View.VISIBLE
                binding.tvRowLabel.visibility = View.GONE
                binding.tvSectionTitle.text = item.title
            }
        }
    }

    inner class SeatViewHolder(private val binding: ItemSeatBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(seat: Seat) {
            binding.tvSeatNumber.text = seat.seatNumber.toString()

            val ctx = binding.root.context
            when (seat.status) {
                SeatStatus.AVAILABLE -> {
                    val color = if (seat.sectionType == "vip")
                        ctx.getColor(R.color.seat_vip) else ctx.getColor(R.color.seat_available)
                    binding.btnSeat.setBackgroundColor(color)
                    binding.tvSeatNumber.setTextColor(Color.WHITE)
                    binding.btnSeat.isEnabled = true
                    binding.btnSeat.alpha = 1.0f
                }
                SeatStatus.SELECTED -> {
                    binding.btnSeat.setBackgroundColor(ctx.getColor(R.color.seat_selected))
                    binding.tvSeatNumber.setTextColor(Color.WHITE)
                    binding.btnSeat.isEnabled = true
                    binding.btnSeat.alpha = 1.0f
                }
                SeatStatus.BOOKED -> {
                    binding.btnSeat.setBackgroundColor(ctx.getColor(R.color.seat_booked))
                    binding.tvSeatNumber.setTextColor(Color.WHITE)
                    binding.btnSeat.isEnabled = false
                    binding.btnSeat.alpha = 0.6f
                }
            }

            binding.btnSeat.setOnClickListener {
                onSeatClick(seat)
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<SeatItem>() {
        override fun areItemsTheSame(oldItem: SeatItem, newItem: SeatItem): Boolean {
            return when {
                oldItem is SeatItem.SeatCell && newItem is SeatItem.SeatCell ->
                    oldItem.seat.seatId == newItem.seat.seatId
                oldItem is SeatItem.Header && newItem is SeatItem.Header ->
                    oldItem.title == newItem.title && oldItem.rowLabel == newItem.rowLabel
                else -> false
            }
        }

        override fun areContentsTheSame(oldItem: SeatItem, newItem: SeatItem) = oldItem == newItem
    }
}
