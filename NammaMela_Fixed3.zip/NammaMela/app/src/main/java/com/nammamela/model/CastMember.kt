package com.nammamela.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cast_members")
data class CastMember(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val role: String,           // "Lead Actor", "Comedian", "Singer"
    val roleType: String,       // "lead", "comedian", "singer", "support"
    val experience: String,
    val photoUrl: String,
    val actsAppearing: String = "All Acts",
    val bio: String = ""
)
