package com.nammamela.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.nammamela.model.FanComment

@Dao
interface FanCommentDao {

    @Query("SELECT * FROM fan_comments ORDER BY postedAt DESC")
    fun getAllComments(): LiveData<List<FanComment>>

    @Insert
    suspend fun insertComment(comment: FanComment)

    @Query("UPDATE fan_comments SET claps = claps + 1 WHERE id = :commentId")
    suspend fun incrementClaps(commentId: Int)

    @Query("DELETE FROM fan_comments WHERE id = :commentId")
    suspend fun deleteComment(commentId: Int)

    @Query("SELECT COUNT(*) FROM fan_comments")
    suspend fun getCount(): Int
}
