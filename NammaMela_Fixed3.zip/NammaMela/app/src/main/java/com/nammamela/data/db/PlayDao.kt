package com.nammamela.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.nammamela.model.Play

@Dao
interface PlayDao {

    @Query("SELECT * FROM plays WHERE isTonight = 1 LIMIT 1")
    fun getTonightPlay(): LiveData<Play?>

    @Query("SELECT * FROM plays WHERE isTonight = 1 LIMIT 1")
    suspend fun getTonightPlaySync(): Play?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlay(play: Play)

    @Update
    suspend fun updatePlay(play: Play)

    @Query("UPDATE plays SET isTonight = 0")
    suspend fun clearTonightFlag()

    @Query("DELETE FROM plays")
    suspend fun deleteAll()
}
