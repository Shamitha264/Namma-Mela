package com.nammamela.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.nammamela.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Play::class, Seat::class, CastMember::class, FanComment::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class NammaMelaDatabase : RoomDatabase() {

    abstract fun playDao(): PlayDao
    abstract fun seatDao(): SeatDao
    abstract fun castDao(): CastDao
    abstract fun fanCommentDao(): FanCommentDao

    companion object {
        @Volatile
        private var INSTANCE: NammaMelaDatabase? = null

        fun getDatabase(context: Context): NammaMelaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NammaMelaDatabase::class.java,
                    "namma_mela_database"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            INSTANCE?.let { database ->
                                CoroutineScope(Dispatchers.IO).launch {
                                    populateInitialData(database)
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun populateInitialData(db: NammaMelaDatabase) {
            // Insert tonight's play
            db.playDao().insertPlay(
                Play(
                    title = "Chandramukhi Rahasya",
                    language = "Kannada",
                    genre = "Drama",
                    showTime = "7:30 PM",
                    duration = "3 Hours 15 Min",
                    numberOfActs = 4,
                    venue = "Gram Panchayat Maidan, Belagavi",
                    posterUrl = "https://picsum.photos/seed/drama1/400/600",
                    isTonight = true
                )
            )

            // Insert cast members
            val castMembers = listOf(
                CastMember(
                    name = "Rajashekhar Nayak",
                    role = "Lead Actor",
                    roleType = "lead",
                    experience = "28 Years Experience",
                    photoUrl = "https://picsum.photos/seed/actor1/200/200",
                    actsAppearing = "All Acts",
                    bio = "Veteran of Karnataka's drama stage for nearly three decades"
                ),
                CastMember(
                    name = "Hunasimath",
                    role = "Comedian",
                    roleType = "comedian",
                    experience = "Crowd Favourite",
                    photoUrl = "https://picsum.photos/seed/actor2/200/200",
                    actsAppearing = "Acts 1, 2, 4",
                    bio = "Known for his spontaneous wit and timing"
                ),
                CastMember(
                    name = "Savithri Bai",
                    role = "Lead Singer",
                    roleType = "singer",
                    experience = "Classical Voice",
                    photoUrl = "https://picsum.photos/seed/actor3/200/200",
                    actsAppearing = "All Acts",
                    bio = "Classically trained vocalist specialising in folk drama"
                ),
                CastMember(
                    name = "Mallikarjun Patil",
                    role = "Villain",
                    roleType = "support",
                    experience = "15 Years",
                    photoUrl = "https://picsum.photos/seed/actor4/200/200",
                    actsAppearing = "Acts 2–4"
                ),
                CastMember(
                    name = "Yamuna Devi",
                    role = "Backup Vocalist",
                    roleType = "support",
                    experience = "10 Years",
                    photoUrl = "https://picsum.photos/seed/actor5/200/200",
                    actsAppearing = "All Acts"
                ),
                CastMember(
                    name = "Basavanna",
                    role = "Percussion",
                    roleType = "support",
                    experience = "Live Music",
                    photoUrl = "https://picsum.photos/seed/actor6/200/200",
                    actsAppearing = "All Acts"
                )
            )
            db.castDao().insertAllCast(castMembers)

            // Insert seats
            val seats = mutableListOf<Seat>()
            val seatConfig = listOf(
                Triple("VIP", "vip", 8),
                Triple("A", "front", 10),
                Triple("B", "front", 10),
                Triple("C", "mid", 10),
                Triple("D", "mid", 10),
                Triple("E", "back", 12),
                Triple("F", "back", 12)
            )
            val preBooked = mapOf(
                "VIP" to setOf(2, 5),
                "A" to setOf(1, 3, 7),
                "B" to setOf(2, 4, 8, 9),
                "C" to setOf(1, 2, 5),
                "D" to setOf(3, 6, 10),
                "E" to setOf(2, 4, 7, 11),
                "F" to setOf(1, 5, 8, 9, 12)
            )
            for ((row, section, count) in seatConfig) {
                for (num in 1..count) {
                    val status = if (preBooked[row]?.contains(num) == true)
                        SeatStatus.BOOKED else SeatStatus.AVAILABLE
                    seats.add(
                        Seat(
                            seatId = "$row-$num",
                            rowLabel = row,
                            seatNumber = num,
                            sectionType = section,
                            status = status,
                            bookedAt = if (status == SeatStatus.BOOKED) System.currentTimeMillis() else 0L
                        )
                    )
                }
            }
            db.seatDao().insertAllSeats(seats)

            // Insert sample fan comments
            val sampleComments = listOf(
                FanComment(
                    fanName = "Narasimha Rao",
                    comment = "Hunasimath anna made everyone cry with laughter! Best performance I have seen in 10 years!",
                    claps = 24,
                    postedAt = System.currentTimeMillis() - 7200000
                ),
                FanComment(
                    fanName = "Devamma",
                    comment = "Savithri Bai's voice in the second act was divine. The whole audience was silent with goosebumps.",
                    claps = 17,
                    postedAt = System.currentTimeMillis() - 3600000
                ),
                FanComment(
                    fanName = "Prakash Kumar",
                    comment = "We drove from Hubli 60km just for this show. Worth every kilometer! Rajashekhar sir was magnificent.",
                    claps = 31,
                    postedAt = System.currentTimeMillis() - 1800000
                )
            )
            sampleComments.forEach { db.fanCommentDao().insertComment(it) }
        }
    }
}
